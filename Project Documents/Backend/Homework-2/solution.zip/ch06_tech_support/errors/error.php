<?php include '../view/header.php'; ?>
<main>
    <h1>Error</h1>
    <p><?php echo htmlspecialchars($error); ?></p>
</main>
<?php include '../view/footer.php'; ?>